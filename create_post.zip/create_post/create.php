<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create</title>
<link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <link rel="stylesheet" href="./css/create.css">
</head>
<body>
   
 <!-- ================================================= -->

 <?php
 include 'navbar.php';
 
 ?>
 <!-- ================================================= -->





     <div class="title-box">
        <h2 class="title">Create Post</h2>
     </div>
    
     <div class="container">
        <div class="img-area">

         
        <div class="drag-area">
            <div class="icon"><i class="uil uil-image-plus"></i></div>
            <header>Drag & Drop to Upload File</header>
            <span>OR</span>
            <button>Browse File</button>
            <input type="file" hidden>
          </div>
        </div>



          <script src="./scripts/drag.js"></script>



        <div class="text-area">
            <div class="desc">
                <input placeholder="Post Name" type="text">
                <textarea placeholder="Write Description . . ." name="" id="" cols="30" rows="10"></textarea>
                <input placeholder="Price in ETH" type="text">

            </div>
            <div class="create">
                <button>Create</button>
            </div>
       
       
       
       
       
       
       
        </div>
   
   
   
   
   
   
   
    </div>
</body>
</html>